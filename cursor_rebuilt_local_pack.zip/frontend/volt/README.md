Run `git submodule add https://github.com/themesberg/volt-react-dashboard.git frontend/volt` to fetch UI.
